namespace DelphiModernisierung;

public static class Unit2_Versandklasse
{
    public static int ShippingClass(int Grams)
    {
        if (Grams <= 0)
            return -1;
        if (Grams <= 500)
            return 1;
        if (Grams <= 2000)
            return 2;
        if (Grams <= 10000)
            return 3;
        if (Grams <= 31500)
            return 4;

        return -1;
    }
}
