namespace DelphiModernisierung;

public static class Unit1_Rabatt
{
    public static int DiscountPercent(int Amount)
    {
        if (Amount >= 100)
            return 10;
        if (Amount >= 50)
            return 5;

        return 0;
    }
}
