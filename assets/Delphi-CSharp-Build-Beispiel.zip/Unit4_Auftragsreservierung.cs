namespace DelphiModernisierung.Unit4_Auftragsreservierung;

public sealed class TOrderInventory
{
    private int[] FAvailable = System.Array.Empty<int>();
    private int[] FReserved = System.Array.Empty<int>();
    private bool FActive;

    public TOrderInventory(int[] InitialStock)
    {
        int Index;
        System.Array.Resize(ref this.FAvailable, InitialStock.Length);
        System.Array.Resize(ref this.FReserved, InitialStock.Length);
        int __pascalStart0 = 0;
        int __pascalLimit0 = (InitialStock.Length - 1);
        for (long __pascalIndex0 = __pascalStart0; __pascalIndex0 <= __pascalLimit0; __pascalIndex0++)
        {
            Index = (int)__pascalIndex0;
            if (InitialStock[Index] > 0)
            {
                this.FAvailable[Index] = InitialStock[Index];
            }
        }
        this.FActive = false;
    }

    public int Available(int Index)
    {
        return this.FAvailable[Index];
    }

    public int Reserved(int Index)
    {
        return this.FReserved[Index];
    }

    public bool TryReserve(int[] Positions)
    {
        int Index;
        bool HasPosition;
        if (this.FActive || (Positions.Length != this.FAvailable.Length))
        {
            return false;
        }
        HasPosition = false;
        int __pascalStart1 = 0;
        int __pascalLimit1 = (Positions.Length - 1);
        for (long __pascalIndex1 = __pascalStart1; __pascalIndex1 <= __pascalLimit1; __pascalIndex1++)
        {
            Index = (int)__pascalIndex1;
            if ((Positions[Index] < 0) || (Positions[Index] > this.FAvailable[Index]))
            {
                return false;
            }
            if (Positions[Index] > 0)
            {
                HasPosition = true;
            }
        }
        if (!HasPosition)
        {
            return false;
        }
        int __pascalStart2 = 0;
        int __pascalLimit2 = (Positions.Length - 1);
        for (long __pascalIndex2 = __pascalStart2; __pascalIndex2 <= __pascalLimit2; __pascalIndex2++)
        {
            Index = (int)__pascalIndex2;
            this.FAvailable[Index] = (this.FAvailable[Index] - Positions[Index]);
            this.FReserved[Index] = Positions[Index];
        }
        this.FActive = true;
        return true;
    }

    public bool TryCancel()
    {
        int Index;
        if (!this.FActive)
        {
            return false;
        }
        int __pascalStart3 = 0;
        int __pascalLimit3 = (this.FReserved.Length - 1);
        for (long __pascalIndex3 = __pascalStart3; __pascalIndex3 <= __pascalLimit3; __pascalIndex3++)
        {
            Index = (int)__pascalIndex3;
            this.FAvailable[Index] = (this.FAvailable[Index] + this.FReserved[Index]);
            this.FReserved[Index] = 0;
        }
        this.FActive = false;
        return true;
    }
}
