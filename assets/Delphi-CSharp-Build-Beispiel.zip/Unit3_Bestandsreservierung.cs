namespace DelphiModernisierung.Unit3_Bestandsreservierung;

public sealed class TInventory
{
    private int FStock;
    private int FReserved;

    public TInventory(int InitialStock)
    {
        if (InitialStock > 0)
            this.FStock = InitialStock;
        else
            this.FStock = 0;
        this.FReserved = 0;
    }

    private int GetAvailable() => this.FStock - this.FReserved;

    public bool TryReserve(int Quantity)
    {
        if (!(Quantity > 0 && Quantity <= this.Available))
            return false;

        this.FReserved += Quantity;
        return true;
    }

    public bool TryRelease(int Quantity)
    {
        if (!(Quantity > 0 && Quantity <= this.FReserved))
            return false;

        this.FReserved -= Quantity;
        return true;
    }

    public int Available => this.GetAvailable();

    public int Reserved => this.FReserved;
}
