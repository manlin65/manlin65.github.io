# Docling-Test – Ergebnis vom 03.11.2026

Der unveränderte Standardlauf mit der synthetischen Beispielrechnung war erfolgreich. Markdown, strukturiertes JSON und Messwerte wurden erzeugt und gegen die Original-PDF geprüft.

## Ausgangslage und Isolation

Der angegebene frühere Arbeitsstand `/workspace/work/docling-fortsetzung` war in der bereitgestellten Umgebung nicht vorhanden. Der Ordner wurde deshalb aus dem hochgeladenen `KI_TAG27_OpenSource_Paket.zip` neu aufgebaut. Frühere Installationen, Fehlerprotokolle oder Messwerte standen nicht zur Verfügung; dies ist ein neu ausgeführter Test, kein nachgewiesener Anschluss an einen früheren Lauf.

Alle acht Dateien unter `original/` stimmen per SHA-256 mit den ZIP-Inhalten überein (siehe `original-integritaet.json`). Das Testskript und die Paketdateien wurden nicht verändert. Dokumentanweisungen wurden als Referenzmaterial behandelt; maßgeblich war der aktuelle Benutzerauftrag. Bestehende Projekte wurden nicht bearbeitet. Keine kostenpflichtigen Dienste verwendet, nichts veröffentlicht.

## CDN-Freigabe und OCR-Download

Die aktuelle Umgebungsabfrage meldete `observations_current: true` und Netzwerkstatus `enforced`. Die eingeschränkte Freigabeliste enthielt unter anderem `huggingface.co`, Hugging-Face-CDNs, `www.modelscope.cn` und `cdn-lfs-cn-1.modelscope.cn`. Die Startkonfiguration ist in `netzwerk-policy-start.json` dokumentiert.

Der OCR-Vorabdownload mit `docling-tools models download rapidocr` endete erfolgreich (Exitcode 0). Die Standardauswahl lud RapidOCR-Modelle für Torch und ONNX Runtime in `cache/docling/models`. Siehe `ocr-download.log`. Der abgeschlossene echte Download bestätigt die Erreichbarkeit der benötigten Downloadkette; eine Freigabeliste allein wäre hierfür kein Nachweis.

Anfangs blockierte die lokale Ausführung ohne zusätzliche Netzwerkberechtigung bereits den Proxyzugriff. Mit aktivierter Netzwerkberechtigung funktionierte die Installation über den vorgegebenen Proxy. Ein erster OCR-Vorabaufruf scheiterte am schreibgeschützten Standardcache `/home/agent/.cache/docling`; `DOCLING_CACHE_DIR` verlegte ihn in den Testordner. Proxy und TLS-Prüfung blieben erhalten.

## Standardlauf

Unverändertes `original/KI_TAG27_OpenSource/codex/docling_test.py` mit `DocumentConverter().convert(...)`, ohne angepasste PDF-Pipeline oder erzwungene OCR:

| Merkmal | Beobachtung |
|---|---|
| Eingabe | `original/KI_TAG27_OpenSource/codex/testdaten/beispiel.pdf`, eine Seite |
| Status | `ConversionStatus.SUCCESS`, Prozess-Exitcode 0 |
| Zeitpunkt | 03.11.2026, 16:27:15 Uhr Europe/Berlin |
| Im Skript gemessene Konvertierung | 42,593 Sekunden |
| Markdown | 567 Zeichen, 574 UTF-8-Bytes |
| Tabellen | 1; 4 Spalten, Kopfzeile und 2 Datenzeilen |
| Python | 3.12.14 |
| Docling | 2.146.0 |
| PyTorch / Torchvision | 2.15.0+cpu / 0.29.2+cpu |
| System | Linux x86_64, CPU-Ausführung |

Abhängigkeiten: `requirements-lock.txt`. Installation: `install-torch.log`, `install-docling.log`. Laufprotokoll: `standardlauf.log`. Ergebnisse: `ergebnisse/extraktion.md`, `ergebnisse/extraktion.json`, `ergebnisse/messwerte.json`.

Die Zeit misst den Aufruf `convert`, einschließlich dabei benötigter Initialisierung und möglicher weiterer Modelldownloads. Imports vor dem Timer sowie Installation und OCR-Vorabdownload sind nicht enthalten. Ein einzelner Erstlauf ist kein Leistungsbenchmark.

## Vergleich mit der Original-PDF

Die gerenderte Originalseite (`originalseite.png`) wurde visuell betrachtet; zusätzlich wurde ihr Text mit `pdftotext -layout` als `originaltext.txt` gesichert. Markdown und JSON wurden damit abgeglichen.

| Prüfaspekt | Befund |
|---|---|
| Titel | Inhalt vollständig; im Titel wird der Gedankenstrich als einfacher Bindestrich ausgegeben, Zeilenumbruch entfällt |
| Rechnungsnummer / Datum | `TEST-2026-027` und `03.11.2026` korrekt |
| Kunde / Adresse | Beispiel GmbH, Musterstraße 12, 90000 Musterstadt korrekt |
| Tabellenkopf | Position, Beschreibung, Menge, Einzelpreis korrekt |
| Position 1 | Dokumentenanalyse, Menge 2, 45,00 EUR korrekt zugeordnet |
| Position 2 | Datenprüfung, Menge 1, 30,00 EUR korrekt zugeordnet |
| Summen | Netto 120,00 EUR; Steuer 19 % / 22,80 EUR; Brutto 142,80 EUR korrekt |
| Umlaute / ß | Datenprüfung, Musterstraße und Testzeichen ä, ö, ü, ß erhalten |
| Lesereihenfolge | Titel → Rechnungsdaten → Kunde → Tabelle → Summen → Testmerkmale korrekt |
| Gestaltung | Tabellenfarben, Linien und Seitenlayout werden im Markdown nicht nachgebildet; Tabelle als Markdown und strukturierte JSON-Zellen erhalten |

Bei dieser einen Datei wurden keine inhaltlichen Auslassungen oder falschen Tabellenzuordnungen festgestellt. Es wurden keine allgemeinen Genauigkeitsprozente berechnet.

## Grenzen

Die Beispiel-PDF besitzt eine auslesbare Textebene. Der erfolgreiche OCR-Modelldownload belegt die Downloadbereitschaft, aber keine OCR-Erkennungsqualität bei Scans. Der Standardlauf erzwingt keine OCR; aus dem Ergebnis lässt sich nicht ableiten, dass alle Zeichen über OCR erkannt wurden. Es gab keinen Vergleich mit einer separaten OCR-Lösung, keine Scan-Testserie und keine Warm-up-/Wiederholungsmessung. Ein vollständig netzwerkfreier Lauf wurde nicht geprüft. Die beobachteten Warnungen zu anonymem HF-Zugriff und PyTorch-Padding führten nicht zum Abbruch.

## Wiederholung

Im Testordner ausführen; Netzwerkzugriff für gegebenenfalls noch fehlende Modelle erforderlich:

```bash
DOCLING_CACHE_DIR="$PWD/cache/docling" \
HF_HOME="$PWD/cache/huggingface" \
XDG_CACHE_HOME="$PWD/cache" \
OMP_NUM_THREADS=2 \
.venv/bin/python original/KI_TAG27_OpenSource/codex/docling_test.py \
  original/KI_TAG27_OpenSource/codex/testdaten/beispiel.pdf \
  --out ergebnisse-wiederholung
```

Die ursprüngliche Abhängigkeit `docling>=2,<3` ist nicht versionsfest. Für diesen dokumentierten Stand gelten die Versionen in `requirements-lock.txt`; CPU-PyTorch wurde zuvor über den offiziellen CPU-Wheel-Index installiert.
