## Synthetische Testrechnung - keine echten Kundendaten

Rechnungsnummer: TEST-2026-027 | Datum: 03.11.2026

Kunde: Beispiel GmbH, Musterstraße 12, 90000 Musterstadt

|   Position | Beschreibung      |   Menge | Einzelpreis   |
|------------|-------------------|---------|---------------|
|          1 | Dokumentenanalyse |       2 | 45,00 EUR     |
|          2 | Datenprüfung      |       1 | 30,00 EUR     |

Nettosumme: 120,00 EUR | Umsatzsteuer (19 %): 22,80 EUR | Brutto: 142,80 EUR

Testmerkmale: Tabelle, Zahlenwerte, Umlaute (ä, ö, ü, ß) und mehrere Absätze.