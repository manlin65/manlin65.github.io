# KI TAG 27 – Open-Source-Potenziale

## Fertige Dateien
- `web/index.html` – responsive HTML-Auswertung; lokal im Browser öffnen.
- `docs/KI_Tag27_OpenSource_OnePager.pdf` – einseitige Schulungsabgabe.
- `codex/` – isoliertes Docling-Python-Projekt mit synthetischer Test-PDF und Anleitung.

## Empfohlener Ablauf
1. HTML lesen und PDF für Skool prüfen.
2. `codex/README.md` öffnen und Ordner in Codex / VS Code als Workspace öffnen.
3. Test ausführen und Ergebnisdateien anschauen.
4. Erst dann die Web-Auswertung und das PDF um tatsächliche Messwerte ergänzen.

Recherche 03.11.2026. Repository-Metriken gerundet. Keine realen Testausführungen behauptet.
