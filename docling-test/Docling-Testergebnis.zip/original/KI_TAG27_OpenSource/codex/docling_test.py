"""Lokaler und reproduzierbarer Docling-Test. Keine Datenübertragung im Skript."""
from pathlib import Path
from time import perf_counter
from datetime import datetime, timezone
import argparse
import json
import platform
import sys


def run(input_file: Path, output_dir: Path) -> None:
    if not input_file.is_file() or input_file.suffix.lower() != ".pdf":
        raise SystemExit("Bitte eine vorhandene PDF-Datei angeben.")
    output_dir.mkdir(parents=True, exist_ok=True)
    from docling.document_converter import DocumentConverter
    t0 = perf_counter()
    result = DocumentConverter().convert(str(input_file.resolve()))
    elapsed = round(perf_counter() - t0, 3)
    document = result.document
    markdown = document.export_to_markdown()
    (output_dir / "extraktion.md").write_text(markdown, encoding="utf-8")
    (output_dir / "extraktion.json").write_text(
        json.dumps(document.export_to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    metric = {
        "zeitpunkt_utc": datetime.now(timezone.utc).isoformat(),
        "dateiname": input_file.name,
        "status": str(result.status),
        "laufzeit_sekunden": elapsed,
        "zeichen_markdown": len(markdown),
        "tabellen_anzahl": len(document.tables),
        "python": sys.version.split()[0],
        "betriebssystem": platform.platform(),
        "bewertung_textvollstaendigkeit": "manuell_pruefen",
        "bewertung_tabellen": "manuell_pruefen",
        "hinweis": "Laufzeit ist kein Benchmark ohne Wiederholungen und gleiches System."
    }
    (output_dir / "messwerte.json").write_text(json.dumps(metric, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(metric, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Docling-Test: PDF zu Markdown/JSON")
    ap.add_argument("pdf", type=Path)
    ap.add_argument("--out", type=Path, default=Path("ergebnisse"))
    ns = ap.parse_args()
    run(ns.pdf, ns.out)
