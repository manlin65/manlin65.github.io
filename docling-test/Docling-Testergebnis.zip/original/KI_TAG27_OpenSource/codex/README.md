# KI TAG 27 – Docling-Test (separat von bestehenden Produktprojekten)

**Status:** lauffähiger Testcode vorbereitet, Docling noch nicht installiert oder ausgeführt.

## Voraussetzungen
- Windows 11, Python 3.12, genügend freier Speicher und RAM
- Internetzugang für Installation und gegebenenfalls erstmaligen Modell-Download
- Ausschließlich synthetische oder freigegebene Test-PDFs verwenden

## Windows PowerShell
```powershell
cd codex
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python docling_test.py .\testdaten\beispiel.pdf --out .\ergebnisse
```

Die Datei `testdaten/beispiel.pdf` wird im Paket mitgeliefert. Die Ergebnisse (Markdown, JSON, Messwerte) landen in `ergebnisse/`.

## Prüfung
1. `extraktion.md` gegen die Original-PDF vergleichen (Vollständigkeit/Lesereihenfolge).
2. Tabellen, Umlaute und Überschriften bewerten.
3. Verarbeitung mit bestehender OCR-Lösung auf derselben Datei wiederholen.
4. Zeitmessung mehrfach und nach Warm-up durchführen, wenn ein Leistungsvergleich benötigt wird.

**Wichtig:** Nicht von einem lokalen Python-Skript automatisch auf vollständige Offline-Verarbeitung schließen: Docling kann beim ersten Durchlauf Modelle/Artefakte nachladen. Datenschutz- und Lizenzprüfung vor Nutzung echter Kundendaten.

## Codex-Auftrag
- Isoliert in diesem Ordner arbeiten.
- Bestehende GitHub-Repositories / Produkte nicht verändern.
- Skript mit Test-PDF ausführen, Fehler beheben und `ergebnisse/` dokumentieren.
- Ausgabe anhand des PDFs manuell prüfen; keine Qualitätsmetriken erfinden.
- Zum Schluss knappe Befunde und ggf. Installationsprobleme notieren.
