M. LINNER - KORRIGIERTES MARKENBUCH ZUR WEBSITE
Stand: 23. Oktober 2026

Grundlage: das zuletzt bestaetigte M_Linner_Brandbook_Logo_Paket(2).zip.
Logo: die bekannte ML-Form mit drei Detailstufen, keine neue Logoform.
Slogan: KI sinnvoll einsetzen. Daten nutzbar machen. Loesungen entwickeln.
Leistungszeile: KI. Datenbanken. Programmierung.

M_Linner_Markenbuch_Website.pdf: neu erstelltes Markenbuch mit 10 Seiten.
M_Linner_Markenbuch_Website.html: dieselben Inhalte mit eingebetteten Bildern
und Schriften. Funktioniert offline im Browser.

Logos/SVG und Logos/PNG: die je 11 Originaldateien.
Icons: alle 15 Originaldateien in 32, 64, 128, 256 und 512 px.
Vorlagen: beide originalen Kontaktvorlagen in 1920 x 1080 px.
Schriften: lokale Schriftdateien mit unveraenderten OFL-Lizenztexten.
Website: Markenwerte und Zuordnung zu den verwendeten Website-Dateien.
Vorschau: Desktop, Mobil, Projekte und Uebersicht des neuen Markenbuchs.
Quellen_und_Grundlagen.md: Herkunft der Logo-Dateien, der Referenzseite und Schriften.

Die Gestaltung folgt der Website. Alle originalen Detail-, Kompakt- und
Icon-Varianten des korrekten Markenpakets sind enthalten.

Kleine Darstellung: Icon. Mittlere Darstellung: Kompakt. Grosse Darstellung:
Detail. Die SVGs enthalten teilweise beschriftete technische Motive; fuer eine
ueberall identische Bilddarstellung stehen die originalen PNGs zur Verfuegung.

Fuer einen PDF-Druck aus der HTML-Datei: A4, Raender 0,
Hintergrundgrafiken an und Browser-Kopf-/Fusszeilen aus.
