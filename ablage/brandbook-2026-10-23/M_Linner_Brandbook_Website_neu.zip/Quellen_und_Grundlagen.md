# Grundlagen und Quellen

Stand: 23. Oktober 2026.

## Korrektes Markenpaket

Nutzer-Upload: M_Linner_Brandbook_Logo_Paket(2).zip.
SHA-256: 6ad3b63b2033290bb7a1c02f82fff39de83a02826370ae8fac3d9afe9dbb48fd.
Die Dateien in Logos, Icons und Vorlagen wurden unveraendert uebernommen.

## Website

Die hier gemeinsam ueberarbeitete, lokal gespeicherte Website liefert Farben,
Typografie, Texte und Desktop-/Mobilvorschauen. Kein neuer Abruf der Live-Seite.

## Schriften

Manrope und Source Sans 3 werden mit ihren unveraenderten OFL-Lizenztexten
mitgeliefert. Die Kontaktbilder sind unveraenderte Originalvorlagen.
