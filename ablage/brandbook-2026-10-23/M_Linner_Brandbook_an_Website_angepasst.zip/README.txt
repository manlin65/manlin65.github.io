M. LINNER - MARKENBUCH ZUR WEBSITE
Stand: 23. Oktober 2026

M_Linner_Markenbuch_Website.pdf: fertiges Markenbuch mit 10 Seiten.
M_Linner_Markenbuch_Website.html: dieselben 10 Seiten im Browser; Bilder und
Schriften sind eingebettet. Funktioniert ohne Internet oder Installation.
Zum PDF-Druck: A4, Raender 0, Hintergrundgrafiken an, Kopf-/Fusszeilen aus.

Logos/SVG: Vektordateien mit Schrift als Pfaden, fuer den direkten Einsatz.
Logos/SVG_editierbar: bearbeitbare Textfassung der Logos; Markenschriften noetig.
Logos/PNG: transparente Rasterdateien fuer helle und dunkle Hintergruende.
Schriften: lokale variable Schriften mit unveraenderten SIL-OFL-Lizenztexten.
Website: Farbwerte und Beschreibung der Verbindung zur Referenzseite.
Vorschau: Desktop-/Mobilbeispiele und Kontaktbogen des Markenbuchs.

Die 2b-Form wurde aus dem hochgeladenen Markenpaket uebernommen. Die Farben
folgen dem CSS der hier ueberarbeiteten Website. Der Markenname lautet im
Auftritt Manfred Linner; die Leistungszeile KI. Datenbanken. Programmierung.

Helle SVGs sind fuer helle, dunkle SVGs fuer dunkle Hintergruende gestaltet.
Das dunkle quadratische Icon enthaelt eine Navy-Kachel. Die separat benannten
Signets haben auch in der dunklen Variante einen transparenten Hintergrund.
Die Kleinformat-Zeichen verzichten bewusst auf die Datenroute.

Fuer Druckauftraege mit CMYK-Vorgaben die Umwandlung mit der Druckerei und
deren Ausgabeprofil abstimmen. Das Paket enthaelt RGB-Werte der Website.
